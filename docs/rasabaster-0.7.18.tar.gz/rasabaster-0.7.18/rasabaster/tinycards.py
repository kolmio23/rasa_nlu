from __future__ import absolute_import
from docutils import nodes
import jinja2
from docutils.parsers.rst.directives import unchanged
from docutils.parsers.rst import Directive

# row of 3 small cards

TINYCARDS_TEMPLATE = jinja2.Template(u"""
<div class="columns smtb tinycard">
  <div class="column tiny">
    <a href="{{ link1 }}" class="card-link" target="_blank">
       <div class="card card-simple">
         <h4>{{ title1 }}</h4>
         <p>{{ subtitle1 }}</p>
         <img src="{{image_url1}}">
       </div>
    </a>
  </div>
  <div class="column tiny">
    <a href="{{ link2 }}" class="card-link" target="_blank">
       <div class="card card-simple">
         <h4>{{ title2 }}</h4>
         <p>{{ subtitle2 }}</p>
         <img src="{{image_url2}}">
       </div>
    </a>
  </div>
  <div class="column tiny">
    <a href="{{ link3 }}" class="card-link" target="_blank">
       <div class="card card-simple">
         <h4>{{ title3 }}</h4>
         <p>{{ subtitle3 }}</p>
         <img src="{{image_url3}}">
       </div>
    </a>
  </div>
</div>
""")

# placeholder node for document graph
class tinycards_node(nodes.General, nodes.Element):
    pass

class TinycardsDirective(Directive):
    required_arguments = 0

    option_spec = {
        'title1': unchanged,
        'link1': unchanged,
        'subtitle1': unchanged,
        'image_url1': unchanged,
        'title2': unchanged,
        'link2': unchanged,
        'subtitle2': unchanged,
        'image_url2': unchanged,
        'title3': unchanged,
        'link3': unchanged,
        'subtitle3': unchanged,
        'image_url3': unchanged,

    }

    # this will execute when your directive is encountered
    # it will insert a tinycards_node into the document that will
    # get visisted during the build phase
    def run(self):
        env = self.state.document.settings.env
        app = env.app

        node = tinycards_node()
        node['title1'] = self.options['title1']
        node['link1'] = self.options['link1']
        node['subtitle1'] = self.options['subtitle1']
        node['image_url1'] = self.options['image_url1']
        node['title2'] = self.options['title2']
        node['link2'] = self.options['link2']
        node['subtitle2'] = self.options['subtitle2']
        node['image_url2'] = self.options['image_url2']
        node['title3'] = self.options['title3']
        node['link3'] = self.options['link3']
        node['subtitle3'] = self.options['subtitle3']
        node['image_url3'] = self.options['image_url3']
        return [node]

# build phase visitor emits HTML to append to output
def html_visit_tinycards_node(self, node):
    html = TINYCARDS_TEMPLATE.render(title1=node['title1'],
                                      link1=node['link1'],
                                      subtitle1=node['subtitle1'],
                                      image_url1=node['image_url1'],
                                      title2=node['title2'],
                                      link2=node['link2'],
                                      subtitle2=node['subtitle2'],
                                      image_url2=node['image_url2'],
                                      title3=node['title3'],
                                      link3=node['link3'],
                                      subtitle3=node['subtitle3'],
                                      image_url3=node['image_url3'])
    self.body.append(html)
    raise nodes.SkipNode

# if you want to be pedantic, define text, latex, manpage visitors too..

def setup(app):
    app.add_node(tinycards_node,
                 html=(html_visit_tinycards_node, None))
    app.add_directive('tinycards', TinycardsDirective)

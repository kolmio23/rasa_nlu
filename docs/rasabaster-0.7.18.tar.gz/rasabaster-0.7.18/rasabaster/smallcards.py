from __future__ import absolute_import
from docutils import nodes
import jinja2
from docutils.parsers.rst.directives import unchanged
from docutils.parsers.rst import Directive

SMALLCARDS_TEMPLATE = jinja2.Template(u"""
<div class="columns smtb">
  <div class="column">
    <a href="{{ link1 }}" class="card-link">
       <div class="card card-simple">
         <h4>{{ description1 }}</h4>
         <button class="button">{{ title1 }}</button>
       </div>
    </a>    
  </div>
  <div class="column">
    <a href="{{ link2 }}" class="card-link">
       <div class="card card-simple">
         <h4>{{ description2 }}</h4>
         <button class="button">{{ title2 }}</button>
       </div>
    </a>    
  </div>
</div>
""")

# placeholder node for document graph
class smallcards_node(nodes.General, nodes.Element):
    pass

class SmallcardsDirective(Directive):
    required_arguments = 0

    option_spec = {
        'title1': unchanged,
        'link1': unchanged,
        'description1': unchanged,
        'title2': unchanged,
        'link2': unchanged,
        'description2': unchanged
    }

    # this will execute when your directive is encountered
    # it will insert a smallcards_node into the document that will
    # get visisted during the build phase
    def run(self):
        env = self.state.document.settings.env
        app = env.app

        node = smallcards_node()
        node['title1'] = self.options['title1']
        node['link1'] = self.options['link1']
        node['description1'] = self.options['description1']
        node['title2'] = self.options['title2']
        node['link2'] = self.options['link2']
        node['description2'] = self.options['description2']
        return [node]

# build phase visitor emits HTML to append to output
def html_visit_smallcards_node(self, node):
    html = SMALLCARDS_TEMPLATE.render(title1=node['title1'],
                                      link1=node['link1'],
                                      description1=node['description1'],
                                      title2=node['title2'],
                                      link2=node['link2'],
                                      description2=node['description2'])
    self.body.append(html)
    raise nodes.SkipNode

# if you want to be pedantic, define text, latex, manpage visitors too..

def setup(app):
    app.add_node(smallcards_node,
                 html=(html_visit_smallcards_node, None))
    app.add_directive('smallcards', SmallcardsDirective)

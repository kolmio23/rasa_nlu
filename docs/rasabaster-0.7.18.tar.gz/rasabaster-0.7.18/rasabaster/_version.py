__version_info__ = (0, 7, 18)
__version__ = '.'.join(map(str, __version_info__))

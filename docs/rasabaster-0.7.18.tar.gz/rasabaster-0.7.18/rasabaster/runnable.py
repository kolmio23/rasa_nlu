from __future__ import absolute_import
from docutils import nodes
import jinja2
from docutils.parsers.rst.directives import unchanged
from docutils.parsers.rst import Directive

RUNNABLE_TEMPLATE = jinja2.Template(u"""

  <pre data-executable>{{code}}</pre>
  <script src="https://storage.googleapis.com/docs-theme/juniper.min.js"></script>
  <script>
    new Juniper({ repo: 'RasaHQ/rasa_core', branch: 'master', isolateCells: false , theme: 'xq-light', eventName: '{{description}}' })
    document.addEventListener('{{description}}', event => {
      if (event.detail.status == 'executing') {
        console.error("{{description}}");
	console.error(JSON.stringify(event));
        console.error(event.currentTarget)
        gtag('event', 'execute-code-snippet', {
          'event_category': 'code',
          'event_label': "{{description}}"
        });
      }
      if (event.detail.status == 'failed') {
        gtag('event', e.action, {
          'event_category': 'code',
          'event_label': e.text
        });
      }
    })
  </script>
""")

# placeholder node for document graph
class runnable_node(nodes.General, nodes.Element):
    pass

class RunnableDirective(Directive):
    has_content = True
    required_arguments = 0

    option_spec = {
        'description': unchanged,
        'code': unchanged
    }

    # this will execute when your directive is encountered
    # it will insert a runnable_node into the document that will
    # get visisted during the build phase
    def run(self):
        env = self.state.document.settings.env
        app = env.app

        #app.add_stylesheet('runnable.css')

        node = runnable_node()
        node['description'] = self.options.get('description') or ''
        node['code'] = u'\n'.join(self.content) #self.options['code']
        return [node]

# build phase visitor emits HTML to append to output
def html_visit_runnable_node(self, node):
    html = RUNNABLE_TEMPLATE.render(description=node['description'], code=node['code'])
    self.body.append(html)
    raise nodes.SkipNode

# if you want to be pedantic, define text, latex, manpage visitors too..

def setup(app):
    app.add_node(runnable_node,
                 html=(html_visit_runnable_node, None))
    app.add_directive('runnable', RunnableDirective)

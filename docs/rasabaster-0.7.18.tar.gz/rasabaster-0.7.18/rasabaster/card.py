from __future__ import absolute_import
from docutils import nodes
import jinja2
from docutils.parsers.rst.directives import unchanged
from docutils.parsers.rst import Directive

CARD_TEMPLATE = jinja2.Template(u"""
<div class="card smb">
  <div class="columns">
    <div class="column">
    <h3>{{ title }}</h3>
      <p>{{ description }}</p>
      <h4><a href="{{ link }}">{{subtitle}}</a></h4>
    </div>
    <div class="column">
      <img src="{{image_url}}">
    </div>
  </div>
</div>
""")

# placeholder node for document graph
class card_node(nodes.General, nodes.Element):
    pass

class CardDirective(Directive):
    required_arguments = 0

    option_spec = {
        'title': unchanged,
        'subtitle': unchanged,
        'link': unchanged,
        'description': unchanged,
        'image_url': unchanged,
    }

    # this will execute when your directive is encountered
    # it will insert a card_node into the document that will
    # get visisted during the build phase
    def run(self):
        env = self.state.document.settings.env
        app = env.app

        node = card_node()
        node['title'] = self.options['title']
        node['subtitle'] = self.options['subtitle']
        node['link'] = self.options['link']
        node['description'] = self.options['description']
        node['image_url'] = self.options['image_url']
        return [node]

# build phase visitor emits HTML to append to output
def html_visit_card_node(self, node):
    html = CARD_TEMPLATE.render(title=node['title'],
                                subtitle=node['subtitle'],
                                link=node['link'],
                                description=node['description'],
                                image_url=node['image_url'])
    self.body.append(html)
    raise nodes.SkipNode

# if you want to be pedantic, define text, latex, manpage visitors too..

def setup(app):
    app.add_node(card_node,
                 html=(html_visit_card_node, None))
    app.add_directive('card', CardDirective)

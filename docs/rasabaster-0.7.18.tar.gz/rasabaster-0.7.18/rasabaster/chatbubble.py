from __future__ import absolute_import
from docutils import nodes
import jinja2
from docutils.parsers.rst.directives import unchanged
from docutils.parsers.rst import Directive

BUBBLE_TEMPLATE = jinja2.Template(u"""
  <div class="chat-bubble {{sender}}">
    <p>{{ text }}</p>
  </div>
""")

# placeholder node for document graph
class bubble_node(nodes.General, nodes.Element):
    pass

class ChatBubbleDirective(Directive):
    required_arguments = 0

    option_spec = {
        'text': unchanged,
        'sender': unchanged,
    }

    # this will execute when your directive is encountered
    # it will insert a button_node into the document that will
    # get visisted during the build phase
    def run(self):
        env = self.state.document.settings.env
        app = env.app

        node = bubble_node()
        node['text'] = self.options['text']
        node['sender'] = self.options['sender']
        return [node]

# build phase visitor emits HTML to append to output
def html_visit_bubble_node(self, node):
    html = BUBBLE_TEMPLATE.render(text=node['text'], sender=node['sender'])
    self.body.append(html)
    raise nodes.SkipNode

# if you want to be pedantic, define text, latex, manpage visitors too..

def setup(app):
    app.add_node(bubble_node,
                 html=(html_visit_bubble_node, None))
    app.add_directive('chat-bubble', ChatBubbleDirective)

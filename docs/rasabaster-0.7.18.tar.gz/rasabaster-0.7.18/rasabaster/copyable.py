from __future__ import absolute_import
from docutils import nodes
import jinja2
from docutils.parsers.rst.directives import unchanged
from docutils.parsers.rst import Directive

COPYABLE_TEMPLATE = jinja2.Template(u"""
  <pre class="snippet">
    <div class="code copyable" data-clipboard-text="{{code}}">
      {{code}}
    </div>
    <button class="button copyable" data-clipboard-text="{{code}}">copy</button>
    <div class="copyable confirm" id="{{code[:3]}}">copied!</div>
  </pre>

""")

# placeholder node for document graph
class copyable_node(nodes.General, nodes.Element):
    pass

class CopyableDirective(Directive):
    has_content = True
    required_arguments = 0

    option_spec = {
        'code': unchanged
    }

    # this will execute when your directive is encountered
    # it will insert a copyable_node into the document that will
    # get visisted during the build phase
    def run(self):
        env = self.state.document.settings.env
        app = env.app

        #app.add_stylesheet('copyable.css')

        node = copyable_node()
        node['code'] = u'\n'.join(self.content) #self.options['code']
        return [node]

# build phase visitor emits HTML to append to output
def html_visit_copyable_node(self, node):
    html = COPYABLE_TEMPLATE.render(code=node['code'])
    self.body.append(html)
    raise nodes.SkipNode

# if you want to be pedantic, define text, latex, manpage visitors too..

def setup(app):
    app.add_node(copyable_node,
                 html=(html_visit_copyable_node, None))
    app.add_directive('copyable', CopyableDirective)
